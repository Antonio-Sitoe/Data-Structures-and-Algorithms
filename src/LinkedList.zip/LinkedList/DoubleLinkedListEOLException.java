package LinkedList;

public class DoubleLinkedListEOLException extends Exception {
	private static final long serialVersionUID = 1L;
	public DoubleLinkedListEOLException(String str) {
		super(str);
	}
}
